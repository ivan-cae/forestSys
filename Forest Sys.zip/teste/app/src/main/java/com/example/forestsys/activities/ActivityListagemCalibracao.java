package com.example.forestsys.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import static com.example.forestsys.activities.ActivityMain.osSelecionada;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.forestsys.AdaptadorCalibragem;
import com.example.forestsys.AdaptadorInsumos;
import com.example.forestsys.BaseDeDados;
import com.example.forestsys.DAO;
import com.example.forestsys.R;
import com.example.forestsys.classes.CALIBRAGEM_SUBSOLAGEM;

import java.util.List;

public class ActivityListagemCalibracao extends AppCompatActivity {

    private Button adicionarCalibracao;
    private TextView os;
    private TextView status;
    private TextView descricao;
    private TextView area;
    private RecyclerView recyclerView;
    private AdaptadorCalibragem adaptador;
    private List<CALIBRAGEM_SUBSOLAGEM> calibragens;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listagem_calibracao);

        os = findViewById(R.id.listagem_calibracao_idos);
        status = findViewById(R.id.listagem_calibracao_status);
        descricao = findViewById(R.id.listagem_calibracao_descricao);
        area = findViewById(R.id.listagem_calibracao_area);

        os.setText(osSelecionada.getID_PROGRAMACAO_ATIVIDADE().toString());

        BaseDeDados baseDeDados = BaseDeDados.getInstance(getApplicationContext());
        DAO dao = baseDeDados.dao();

        calibragens = dao.listaCalibragem(osSelecionada.getID_PROGRAMACAO_ATIVIDADE());

        recyclerView = findViewById(R.id.recycler_calibracao);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        adaptador = new AdaptadorCalibragem();
        recyclerView.setAdapter(adaptador);

        adaptador.setCalibragem(calibragens);

        adicionarCalibracao = findViewById(R.id.botao_adicionar_calibracao);
        adicionarCalibracao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(ActivityListagemCalibracao.this, ActivityCalibragem.class);
                startActivity(it);
            }
        });
    }
}
