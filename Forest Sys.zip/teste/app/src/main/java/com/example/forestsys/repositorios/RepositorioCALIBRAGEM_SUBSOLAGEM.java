package com.example.forestsys.repositorios;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import com.example.forestsys.BaseDeDados;
import com.example.forestsys.DAO;
import com.example.forestsys.classes.CALIBRAGEM_SUBSOLAGEM;

import java.sql.Date;

public class RepositorioCALIBRAGEM_SUBSOLAGEM {
    private DAO dao;

    public RepositorioCALIBRAGEM_SUBSOLAGEM(Application application) {
        BaseDeDados baseDeDados = BaseDeDados.getInstance(application);
        dao = baseDeDados.dao();
    }

    //retorna uma instância da Classe CALIBRAGEM_SUBSOLAGEM
//parâmetro de entrada: valores dados respectivos a chave composta para busca na tabela CALIBRAGEM_SUBSOLAGEM
    public LiveData<CALIBRAGEM_SUBSOLAGEM> getCalibragem(int idProg, Date data, String turno, int idMaqImp) {
        return dao.selecionaCalibragem(idProg, data, turno, idMaqImp);
    }

    //inclui uma instância da Classe CALIBRAGEM_SUBSOLAGEM no DB
//parâmetro de entrada: instancia da Classe CALIBRAGEM_SUBSOLAGEM
    public void insert(CALIBRAGEM_SUBSOLAGEM calibragemSubsolagem) {
        new RepositorioCALIBRAGEM_SUBSOLAGEM.InsertAsyncTask(dao).execute(calibragemSubsolagem);
    }

    //atualiza uma instância da Classe CALIBRAGEM_SUBSOLAGEM no DB
//parâmetro de entrada: instancia da Classe CALIBRAGEM_SUBSOLAGEM
    public void update(CALIBRAGEM_SUBSOLAGEM calibragemSubsolagem) {
        new RepositorioCALIBRAGEM_SUBSOLAGEM.UpdateAsyncTask(dao).execute(calibragemSubsolagem);
    }

    //apaga uma instância da ClasseOs no DB
//parâmetro de entrada: instancia da ClasseOs
    public void delete(CALIBRAGEM_SUBSOLAGEM calibragemSubsolagem) {
        new RepositorioCALIBRAGEM_SUBSOLAGEM.DeleteAsyncTask(dao).execute(calibragemSubsolagem);
    }


    private static class InsertAsyncTask extends AsyncTask<CALIBRAGEM_SUBSOLAGEM, Void, Void> {
        private DAO dao;

        private InsertAsyncTask(DAO dao) {
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(CALIBRAGEM_SUBSOLAGEM... calib) {
            dao.insert(calib[0]);
            return null;
        }
    }

    private static class UpdateAsyncTask extends AsyncTask<CALIBRAGEM_SUBSOLAGEM, Void, Void> {
        private DAO dao;

        private UpdateAsyncTask(DAO dao) {
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(CALIBRAGEM_SUBSOLAGEM... calib) {
            dao.update(calib[0]);
            return null;
        }
    }


    private static class DeleteAsyncTask extends AsyncTask<CALIBRAGEM_SUBSOLAGEM, Void, Void> {
        private DAO dao;

        private DeleteAsyncTask(DAO dao) {
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(CALIBRAGEM_SUBSOLAGEM... calib) {
            dao.delete(calib[0]);
            return null;
        }
    }
}
