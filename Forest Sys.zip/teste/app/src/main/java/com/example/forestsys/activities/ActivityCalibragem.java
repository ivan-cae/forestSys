package com.example.forestsys.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.text.format.DateFormat;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.forestsys.R;
import com.example.forestsys.calculadora.i.CalculadoraMain;

import com.example.forestsys.classes.GGF_USUARIOS;
import com.example.forestsys.classes.IMPLEMENTOS;
import com.example.forestsys.classes.MAQUINAS;
import com.example.forestsys.classes.MAQUINA_IMPLEMENTO;
import com.example.forestsys.repositorios.RepositorioCALIBRAGEM_SUBSOLAGEM;
import com.example.forestsys.repositorios.RepositorioImplementos;
import com.example.forestsys.repositorios.RepositorioMAQUINA_IMPLEMENTO;
import com.example.forestsys.repositorios.RepositorioMaquinas;
import com.example.forestsys.repositorios.RepositorioUsers;
import com.google.android.material.navigation.NavigationView;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import static com.example.forestsys.activities.ActivityLogin.nomeEmpresaPref;
import static com.example.forestsys.activities.ActivityMain.osSelecionada;

public class ActivityCalibragem extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawer;
    private TextView idOs;

    private EditText p1_a1;
    private EditText p1_a2;
    private EditText p1_a3;
    private EditText p1_a4;
    private EditText p1_a5;

    private TextView p1Media;


    private EditText p2_a1;
    private EditText p2_a2;
    private EditText p2_a3;
    private EditText p2_a4;
    private EditText p2_a5;

    private TextView p2Media;


    private TextView dif1_p1;
    private TextView dif2_p1;
    private TextView dif3_p1;
    private TextView dif4_p1;
    private TextView mediaDifP2;

    private TextView dif1_p2;
    private TextView dif2_p2;
    private TextView dif3_p2;
    private TextView dif4_p2;
    private TextView mediaDifP1;

    private TextView mediaProduto1;
    private TextView mediaProduto2;
    private TextView desvioProduto1;
    private TextView desvioProduto2;


    private Spinner spinnerOperador;
    private Spinner spinnerMaquina;
    private Spinner spinnerImplemento;

    private TextView osTalhao;
    private TextView osData;
    private TextView osTurno;
    private EditText digitaAmostra;

    private ImageButton botaoMediaP1;
    private ImageButton botaoMediaP2;
    private ImageButton botaoConfirma;
    private ImageButton botaoVoltar;

    private Button botaoAmostra;

    boolean todosConformeP1 = false;
    boolean todosConformeP2 = false;

    private ObjectAnimator objAnim;

    private int atualP2;
    private int atualP1;

    private String texto;

    private Double[] amostrasP1 = new Double[5];
    private Double[] amostrasP2 = new Double[5];

    private int posicaoImplemento;
    private int posicaoMaquina;
    private int posicaoOperador;

    private Double mediaPercentualp1;
    private Double mediaGeralp1;

    private Double mediaPercentualp2;
    private Double mediaGeralp2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calibragem);
        setTitle(nomeEmpresaPref);

        spinnerOperador = findViewById(R.id.spinner_operador_calibragem);
        spinnerMaquina = findViewById(R.id.spinner_maquina_calibragem);
        spinnerImplemento = findViewById(R.id.spinner_implemento_calibragem);

        osData = findViewById(R.id.data_os_calibragem);
        osTalhao = findViewById(R.id.talhao_os_calibragem);
        osTurno = findViewById(R.id.turno_os_calibragem);

        mediaProduto1 = findViewById(R.id.media_produto1);
        mediaProduto2 = findViewById(R.id.media_produto2);

        desvioProduto1 = findViewById(R.id.desvio_produto1);
        desvioProduto2 = findViewById(R.id.desvio_produto2);

        p1_a1 = findViewById(R.id.p1_amostra_1);
        p1_a2 = findViewById(R.id.p1_amostra_2);
        p1_a3 = findViewById(R.id.p1_amostra_3);
        p1_a4 = findViewById(R.id.p1_amostra_4);
        p1_a5 = findViewById(R.id.p1_amostra_5);
        p1Media = findViewById(R.id.p1_media);

        p1_a1.setFocusable(false);

        p2_a1 = findViewById(R.id.p2_amostra_1);
        p2_a2 = findViewById(R.id.p2_amostra_2);
        p2_a3 = findViewById(R.id.p2_amostra_3);
        p2_a4 = findViewById(R.id.p2_amostra_4);
        p2_a5 = findViewById(R.id.p2_amostra_5);
        p2Media = findViewById(R.id.p2_media);

        dif1_p1 = findViewById(R.id.dif1_p1);
        dif2_p1 = findViewById(R.id.dif2_p1);
        dif3_p1 = findViewById(R.id.dif3_p1);
        dif4_p1 = findViewById(R.id.dif4_p1);
        mediaDifP1 = findViewById(R.id.media_dif_p1);

        dif1_p2 = findViewById(R.id.dif1_p2);
        dif2_p2 = findViewById(R.id.dif2_p2);
        dif3_p2 = findViewById(R.id.dif3_p2);
        dif4_p2 = findViewById(R.id.dif4_p2);
        mediaDifP2 = findViewById(R.id.media_dif_p2);

        botaoConfirma = findViewById(R.id.botao_calibragem_confirma);
        botaoVoltar = findViewById(R.id.botao_calibragem_voltar);

        atualP1 = 1;
        atualP2 = 1;


        idOs = findViewById(R.id.id_os_calibragem);
        idOs.setText(String.valueOf(osSelecionada.getID_PROGRAMACAO_ATIVIDADE()));

        osTalhao.setText(osSelecionada.getTALHAO());

        botaoMediaP1 = findViewById(R.id.botao_calibragem_media_p1);

        botaoMediaP2 = findViewById(R.id.botao_calibragem_media_p2);

        osData.setText(DateFormat.format("dd-MM-yyyy", new Date()).toString());


        osTurno.setText(checaTurno());

        botaoMediaP1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                todosConformeP1 = true;

                if (atualP1 == 1) {
                    p1_a1.setCursorVisible(true);
                    p1_a1.setFocusableInTouchMode(true);
                    p1_a1.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                    p1_a1.requestFocus();

                    InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);
                }
                if (atualP1 == 2) {
                    p1_a2.setCursorVisible(true);
                    p1_a2.setFocusableInTouchMode(true);
                    p1_a2.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                    p1_a2.requestFocus();

                    InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);
                }

                if (atualP1 == 3) {
                    p1_a3.setCursorVisible(true);
                    p1_a3.setFocusableInTouchMode(true);
                    p1_a3.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                    p1_a3.requestFocus();

                    InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);

                }

                if (atualP1 == 4) {
                    p1_a4.setCursorVisible(true);
                    p1_a4.setFocusableInTouchMode(true);
                    p1_a4.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                    p1_a4.requestFocus();

                    InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);

                }

                if (atualP1 == 5) {
                    p1_a5.setCursorVisible(true);
                    p1_a5.setFocusableInTouchMode(true);
                    p1_a5.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                    p1_a5.requestFocus();

                    InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);
                }

                p1_a1.setCursorVisible(false);
                p1_a1.setFocusableInTouchMode(false);
                if (p1_a1.getText().toString().isEmpty()) {
                    amostrasP1[0] = 0.0;
                } else {
                    amostrasP1[0] = Double.valueOf(String.valueOf(p1_a1.getText()));
                }

                p1_a2.setCursorVisible(false);
                p1_a2.setFocusableInTouchMode(false);
                if (p1_a2.getText().toString().isEmpty()) {
                    amostrasP1[1] = 0.0;
                } else {
                    amostrasP1[1] = Double.valueOf(String.valueOf(p1_a2.getText()));
                }

                p1_a3.setCursorVisible(false);
                p1_a3.setFocusableInTouchMode(false);
                if (p1_a3.getText().toString().isEmpty()) {
                    amostrasP1[2] = 0.0;
                } else {
                    amostrasP1[2] = Double.valueOf(String.valueOf(p1_a3.getText()));
                }

                p1_a4.setCursorVisible(false);
                p1_a4.setFocusableInTouchMode(false);
                if (p1_a4.getText().toString().isEmpty()) {
                    amostrasP1[3] = 0.0;
                } else {
                    amostrasP1[3] = Double.valueOf(String.valueOf(p1_a4.getText()));
                }

                p1_a5.setCursorVisible(false);
                p1_a5.setFocusableInTouchMode(false);
                if (p1_a5.getText().toString().isEmpty()) {
                    amostrasP1[4] = 0.0;
                } else {
                    amostrasP1[4] = Double.valueOf(String.valueOf(p1_a5.getText()));
                }

                if (diferencaPercentual(amostrasP1[0], amostrasP1[1]) > 5.00 || diferencaPercentual(amostrasP1[0], amostrasP1[1]) < -5.00) {
                    dif1_p1.setTextColor(Color.parseColor("#FF0000"));
                    if (amostrasP1[0] > amostrasP1[1])
                        p1_a1.setTextColor(Color.parseColor("#FF0000"));
                    else p1_a2.setTextColor(Color.parseColor("#FF0000"));

                    if (atualP1 > 5) {
                        if (amostrasP1[0] > amostrasP1[1]) {
                            p1_a1.setTextColor(Color.parseColor("#FF0000"));
                            p1_a1.setError("Não Conforme!");
                            p1_a1.setCursorVisible(true);
                            p1_a1.setFocusableInTouchMode(true);
                            p1_a1.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                            p1_a1.requestFocus();
                        } else {
                            p1_a2.setTextColor(Color.parseColor("#FF0000"));
                            p1_a2.setError("Não Conforme!");
                            p1_a2.setCursorVisible(true);
                            p1_a2.setFocusableInTouchMode(true);
                            p1_a2.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                            p1_a2.requestFocus();
                        }
                    }
                    todosConformeP1 = false;
                } else {
                    dif1_p1.setTextColor(Color.parseColor("#32CD32"));
                    p1_a1.setTextColor(Color.parseColor("#32CD32"));
                    p1_a2.setTextColor(Color.parseColor("#32CD32"));
                }
                if (String.valueOf((diferencaPercentual(amostrasP1[0], amostrasP1[1]))) == "NaN")
                    dif1_p1.setText("");
                else
                    dif1_p1.setText(String.valueOf((diferencaPercentual(amostrasP1[0], amostrasP1[1]))));


                if (diferencaPercentual(amostrasP1[1], amostrasP1[2]) > 5.00 || diferencaPercentual(amostrasP1[1], amostrasP1[2]) < -5.00) {
                    dif2_p1.setTextColor(Color.parseColor("#FF0000"));
                    if (amostrasP1[1] > amostrasP1[2])
                        p1_a2.setTextColor(Color.parseColor("#FF0000"));
                    else p1_a3.setTextColor(Color.parseColor("#FF0000"));

                    if (atualP1 > 5) {
                        if (amostrasP1[1] > amostrasP1[2]) {
                            p1_a2.setTextColor(Color.parseColor("#FF0000"));
                            p1_a2.setError("Não Conforme!");
                            p1_a2.setCursorVisible(true);
                            p1_a2.setFocusableInTouchMode(true);
                            p1_a2.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                            p1_a2.requestFocus();
                        } else {
                            p1_a3.setTextColor(Color.parseColor("#FF0000"));
                            p1_a3.setError("Não Conforme!");
                            p1_a3.setCursorVisible(true);
                            p1_a3.setFocusableInTouchMode(true);
                            p1_a3.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                            p1_a3.requestFocus();
                        }
                    }
                    todosConformeP1 = false;
                } else {
                    dif2_p1.setTextColor(Color.parseColor("#32CD32"));
                    p1_a2.setTextColor(Color.parseColor("#32CD32"));
                    p1_a3.setTextColor(Color.parseColor("#32CD32"));
                }
                if (String.valueOf((diferencaPercentual(amostrasP1[1], amostrasP1[2]))) == "NaN")
                    dif2_p1.setText("");
                else
                    dif2_p1.setText(String.valueOf((diferencaPercentual(amostrasP1[1], amostrasP1[2]))));


                if (diferencaPercentual(amostrasP1[2], amostrasP1[3]) > 5.00 || diferencaPercentual(amostrasP1[2], amostrasP1[3]) < -5.00) {
                    dif3_p1.setTextColor(Color.parseColor("#FF0000"));
                    if (amostrasP1[2] > amostrasP1[3])
                        p1_a3.setTextColor(Color.parseColor("#FF0000"));
                    else p1_a4.setTextColor(Color.parseColor("#FF0000"));

                    if (atualP1 > 5) {
                        if (amostrasP1[2] > amostrasP1[3]) {
                            p1_a3.setTextColor(Color.parseColor("#FF0000"));
                            p1_a3.setError("Não Conforme!");
                            p1_a3.setCursorVisible(true);
                            p1_a3.setFocusableInTouchMode(true);
                            p1_a3.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                            p1_a3.requestFocus();
                        } else {
                            p1_a4.setTextColor(Color.parseColor("#FF0000"));
                            p1_a4.setError("Não Conforme!");
                            p1_a4.setCursorVisible(true);
                            p1_a4.setFocusableInTouchMode(true);
                            p1_a4.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                            p1_a4.requestFocus();
                        }
                    }
                    todosConformeP1 = false;
                } else {
                    dif3_p1.setTextColor(Color.parseColor("#32CD32"));
                    p1_a3.setTextColor(Color.parseColor("#32CD32"));
                    p1_a4.setTextColor(Color.parseColor("#32CD32"));
                }
                if (String.valueOf((diferencaPercentual(amostrasP1[2], amostrasP1[3]))) == "NaN")
                    dif3_p1.setText("");
                else
                    dif3_p1.setText(String.valueOf((diferencaPercentual(amostrasP1[2], amostrasP1[3]))));

                if (diferencaPercentual(amostrasP1[3], amostrasP1[4]) > 5.00 || diferencaPercentual(amostrasP1[3], amostrasP1[4]) < -5.00) {
                    dif4_p1.setTextColor(Color.parseColor("#FF0000"));
                    if (amostrasP1[3] > amostrasP1[4])
                        p1_a4.setTextColor(Color.parseColor("#FF0000"));
                    else p1_a5.setTextColor(Color.parseColor("#FF0000"));

                    if (atualP1 > 5) {
                        if (amostrasP1[3] > amostrasP1[4]) {
                            p1_a4.setTextColor(Color.parseColor("#FF0000"));
                            p1_a4.setError("Não Conforme!");
                            p1_a4.setCursorVisible(true);
                            p1_a4.setFocusableInTouchMode(true);
                            p1_a4.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                            p1_a4.requestFocus();
                        } else {
                            p1_a5.setTextColor(Color.parseColor("#FF0000"));
                            p1_a5.setError("Não Conforme!");
                            p1_a5.setCursorVisible(true);
                            p1_a5.setFocusableInTouchMode(true);
                            p1_a5.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                            p1_a5.requestFocus();
                        }
                    }
                    todosConformeP1 = false;
                } else {
                    dif4_p1.setTextColor(Color.parseColor("#32CD32"));
                    p1_a4.setTextColor(Color.parseColor("#32CD32"));
                    p1_a5.setTextColor(Color.parseColor("#32CD32"));
                }
                if (String.valueOf((diferencaPercentual(amostrasP1[3], amostrasP1[4]))) == "NaN")
                    dif4_p1.setText("");
                else
                    dif4_p1.setText(String.valueOf((diferencaPercentual(amostrasP1[3], amostrasP1[4]))));

                mediaPercentualp1 = (diferencaPercentual(amostrasP1[0], amostrasP1[1]) +
                        diferencaPercentual(amostrasP1[1], amostrasP1[2]) +
                        diferencaPercentual(amostrasP1[2], amostrasP1[3]) +
                        diferencaPercentual(amostrasP1[3], amostrasP1[4])) / 4;

                mediaGeralp1 = (amostrasP1[0] + amostrasP1[1] + amostrasP1[2] + amostrasP1[3] + amostrasP1[4]) / 5;

                if (String.valueOf((mediaPercentualp1)) == "NaN") mediaDifP1.setText("");
                else mediaDifP1.setText(String.valueOf((mediaPercentualp1)));

                p1Media.setText(String.valueOf((mediaGeralp1)));
                mediaProduto1.setText(String.valueOf((mediaGeralp1)));
                Double aux = desvioPadrao(amostrasP1);
                desvioProduto1.setText(String.valueOf((aux)));

                /*String s[] = new String[2];

                if(atualP1==1) {
                    if (p1_a1.getText().toString().isEmpty() || !p1_a1.getText().toString().contains("."))
                        s[1] = "0";
                    else s = p1_a1.getText().toString().split("\\.");
                    if (atualP1 == 1 && s[1].length() < 3) {
                        p1_a1.setError("Digite 3 Casas Decimais!");
                    }
                    if (atualP1 <= 5 && s[1].length() == 3) atualP1++;
                }

                if(atualP1==2) {
                    if (p1_a2.getText().toString().isEmpty() || !p1_a2.getText().toString().contains("."))
                        s[1] = "0";
                    else s = p1_a2.getText().toString().split("\\.");
                    if (atualP1 == 1 && s[1].length() < 3) {
                        p1_a2.setError("Digite 3 Casas Decimais!");
                    }
                    if (atualP1 <= 5 && s[1].length() == 3) atualP1++;
                }

                if(atualP1==3) {
                    if (p1_a3.getText().toString().isEmpty() || !p1_a3.getText().toString().contains("."))
                        s[1] = "0";
                    else s = p1_a3.getText().toString().split("\\.");
                    if (atualP1 == 1 && s[1].length() < 3) {
                        p1_a3.setError("Digite 3 Casas Decimais!");
                    }
                    if (atualP1 <= 5 && s[1].length() == 3) atualP1++;
                }

                if(atualP1==4) {
                    if (p1_a4.getText().toString().isEmpty() || !p1_a4.getText().toString().contains("."))
                        s[1] = "0";
                    else s = p1_a4.getText().toString().split("\\.");
                    if (atualP1 == 1 && s[1].length() < 3) {
                        p1_a4.setError("Digite 3 Casas Decimais!");
                    }
                    if (atualP1 <= 5 && s[1].length() == 3) atualP1++;
                }

                if(atualP1==5) {
                    if (p1_a5.getText().toString().isEmpty() || !p1_a5.getText().toString().contains("."))
                        s[1] = "0";
                    else s = p1_a5.getText().toString().split("\\.");
                    if (atualP1 == 1 && s[1].length() < 3) {
                        p1_a5.setError("Digite 3 Casas Decimais!");
                    }
                    if (atualP1 <= 5 && s[1].length() == 3) atualP1++;
                }*/

                atualP1++;

                if (todosConformeP1 == true && todosConformeP2 == true) {
                    botaoConfirma.setVisibility(View.VISIBLE);
                    pulseAnimation(botaoConfirma);
                }

                if (todosConformeP1 == false || todosConformeP2 == false)
                    botaoConfirma.setVisibility(View.INVISIBLE);
            }
        });


        botaoMediaP2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                todosConformeP2 = true;

                if (atualP2 < 6) {
                    if (atualP2 == 1) {
                        p2_a1.setCursorVisible(true);
                        p2_a1.setFocusableInTouchMode(true);
                        p2_a1.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                        p2_a1.requestFocus();

                        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);
                    }

                    if (atualP2 == 2) {
                        p2_a2.setCursorVisible(true);
                        p2_a2.setFocusableInTouchMode(true);
                        p2_a2.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                        p2_a2.requestFocus();

                        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);
                    }

                    if (atualP2 == 3) {
                        p2_a3.setCursorVisible(true);
                        p2_a3.setFocusableInTouchMode(true);
                        p2_a3.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                        p2_a3.requestFocus();

                        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);

                    }

                    if (atualP2 == 4) {
                        p2_a4.setCursorVisible(true);
                        p2_a4.setFocusableInTouchMode(true);
                        p2_a4.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                        p2_a4.requestFocus();

                        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);

                    }

                    if (atualP2 == 5) {
                        p2_a5.setCursorVisible(true);
                        p2_a5.setFocusableInTouchMode(true);
                        p2_a5.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                        p2_a5.requestFocus();

                        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);
                    }
                }

                p2_a1.setCursorVisible(false);
                p2_a1.setFocusableInTouchMode(false);
                if (p2_a1.getText().toString().isEmpty()) {
                    amostrasP2[0] = 0.0;
                } else {
                    amostrasP2[0] = Double.valueOf(String.valueOf(p2_a1.getText()));
                }

                p2_a2.setCursorVisible(false);
                p2_a2.setFocusableInTouchMode(false);
                if (p2_a2.getText().toString().isEmpty()) {
                    amostrasP2[1] = 0.0;
                } else {
                    amostrasP2[1] = Double.valueOf(String.valueOf(p2_a2.getText()));
                }

                p2_a3.setCursorVisible(false);
                p2_a3.setFocusableInTouchMode(false);
                if (p2_a3.getText().toString().isEmpty()) {
                    amostrasP2[2] = 0.0;
                } else {
                    amostrasP2[2] = Double.valueOf(String.valueOf(p2_a3.getText()));
                }

                p2_a4.setCursorVisible(false);
                p2_a4.setFocusableInTouchMode(false);
                if (p2_a4.getText().toString().isEmpty()) {
                    amostrasP2[3] = 0.0;
                } else {
                    amostrasP2[3] = Double.valueOf(String.valueOf(p2_a4.getText()));
                }

                p2_a5.setCursorVisible(false);
                p2_a5.setFocusableInTouchMode(false);
                if (p2_a5.getText().toString().isEmpty()) {
                    amostrasP2[4] = 0.0;
                } else {
                    amostrasP2[4] = Double.valueOf(String.valueOf(p2_a5.getText()));
                }


                if (diferencaPercentual(amostrasP2[0], amostrasP2[1]) > 5.00 || diferencaPercentual(amostrasP2[0], amostrasP2[1]) < -5.00) {
                    dif1_p2.setTextColor(Color.parseColor("#FF0000"));
                    if (amostrasP2[0] > amostrasP2[1])
                        p2_a1.setTextColor(Color.parseColor("#FF0000"));
                    else p2_a2.setTextColor(Color.parseColor("#FF0000"));

                    if (atualP2 > 5) {
                        if (amostrasP2[0] > amostrasP2[1]) {
                            p2_a1.setTextColor(Color.parseColor("#FF0000"));
                            p2_a1.setError("Não Conforme!");
                            p2_a1.setCursorVisible(true);
                            p2_a1.setFocusableInTouchMode(true);
                            p2_a1.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                            p2_a1.requestFocus();
                        } else {
                            p2_a2.setTextColor(Color.parseColor("#FF0000"));
                            p2_a2.setError("Não Conforme!");
                            p2_a2.setCursorVisible(true);
                            p2_a2.setFocusableInTouchMode(true);
                            p2_a2.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                            p2_a2.requestFocus();
                        }
                    }
                    todosConformeP2 = false;
                } else {
                    dif1_p2.setTextColor(Color.parseColor("#32CD32"));
                    p2_a1.setTextColor(Color.parseColor("#32CD32"));
                    p2_a2.setTextColor(Color.parseColor("#32CD32"));
                }
                if (String.valueOf((diferencaPercentual(amostrasP2[0], amostrasP2[1]))) == "NaN")
                    dif1_p2.setText("");
                else
                    dif1_p2.setText(String.valueOf((diferencaPercentual(amostrasP2[0], amostrasP2[1]))));


                if (diferencaPercentual(amostrasP2[1], amostrasP2[2]) > 5.00 || diferencaPercentual(amostrasP2[1], amostrasP2[2]) < -5.00) {
                    dif2_p2.setTextColor(Color.parseColor("#FF0000"));
                    if (amostrasP2[1] > amostrasP2[2])
                        p2_a2.setTextColor(Color.parseColor("#FF0000"));
                    else p2_a3.setTextColor(Color.parseColor("#FF0000"));

                    if (atualP2 > 5) {
                        if (amostrasP2[1] > amostrasP2[2]) {
                            p2_a2.setTextColor(Color.parseColor("#FF0000"));
                            p2_a2.setError("Não Conforme!");
                            p2_a2.setCursorVisible(true);
                            p2_a2.setFocusableInTouchMode(true);
                            p2_a2.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                            p2_a2.requestFocus();
                        } else {
                            p2_a3.setTextColor(Color.parseColor("#FF0000"));
                            p2_a3.setError("Não Conforme!");
                            p2_a3.setCursorVisible(true);
                            p2_a3.setFocusableInTouchMode(true);
                            p2_a3.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                            p2_a3.requestFocus();
                        }
                    }
                    todosConformeP2 = false;
                } else {
                    dif2_p2.setTextColor(Color.parseColor("#32CD32"));
                    p2_a2.setTextColor(Color.parseColor("#32CD32"));
                    p2_a3.setTextColor(Color.parseColor("#32CD32"));
                }
                if (String.valueOf((diferencaPercentual(amostrasP2[1], amostrasP2[2]))) == "NaN")
                    dif2_p2.setText("");
                else
                    dif2_p2.setText(String.valueOf((diferencaPercentual(amostrasP2[1], amostrasP2[2]))));

                if (diferencaPercentual(amostrasP2[2], amostrasP2[3]) > 5.00 || diferencaPercentual(amostrasP2[2], amostrasP2[3]) < -5.00) {
                    dif3_p2.setTextColor(Color.parseColor("#FF0000"));
                    if (amostrasP2[2] > amostrasP2[3])
                        p2_a3.setTextColor(Color.parseColor("#FF0000"));
                    else p2_a4.setTextColor(Color.parseColor("#FF0000"));

                    if (atualP2 > 5) {
                        if (amostrasP2[2] > amostrasP2[3]) {
                            p2_a3.setTextColor(Color.parseColor("#FF0000"));
                            p2_a3.setError("Não Conforme!");
                            p2_a3.setCursorVisible(true);
                            p2_a3.setFocusableInTouchMode(true);
                            p2_a3.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                            p2_a3.requestFocus();
                        } else {
                            p2_a4.setTextColor(Color.parseColor("#FF0000"));
                            p2_a4.setError("Não Conforme!");
                            p2_a4.setCursorVisible(true);
                            p2_a4.setFocusableInTouchMode(true);
                            p2_a4.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                            p2_a4.requestFocus();
                        }
                    }
                    todosConformeP2 = false;
                } else {
                    dif3_p2.setTextColor(Color.parseColor("#32CD32"));
                    p2_a3.setTextColor(Color.parseColor("#32CD32"));
                    p2_a4.setTextColor(Color.parseColor("#32CD32"));
                }
                if (String.valueOf((diferencaPercentual(amostrasP2[2], amostrasP2[3]))) == "NaN")
                    dif3_p2.setText("");
                else
                    dif3_p2.setText(String.valueOf((diferencaPercentual(amostrasP2[2], amostrasP2[3]))));

                if (diferencaPercentual(amostrasP2[3], amostrasP2[4]) > 5.00 || diferencaPercentual(amostrasP2[3], amostrasP2[4]) < -5.00) {
                    dif4_p2.setTextColor(Color.parseColor("#FF0000"));
                    if (amostrasP2[3] > amostrasP2[4])
                        p2_a4.setTextColor(Color.parseColor("#FF0000"));
                    else p2_a5.setTextColor(Color.parseColor("#FF0000"));

                    if (atualP2 > 5) {
                        if (amostrasP2[3] > amostrasP2[4]) {
                            p2_a4.setTextColor(Color.parseColor("#FF0000"));
                            p2_a4.setError("Não Conforme!");
                            p2_a4.setCursorVisible(true);
                            p2_a4.setFocusableInTouchMode(true);
                            p2_a4.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                            p2_a4.requestFocus();
                        } else {
                            p2_a5.setTextColor(Color.parseColor("#FF0000"));
                            p2_a5.setError("Não Conforme!");
                            p2_a5.setCursorVisible(true);
                            p2_a5.setFocusableInTouchMode(true);
                            p2_a5.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                            p2_a5.requestFocus();
                        }
                    }
                    todosConformeP2 = false;
                } else {
                    dif4_p2.setTextColor(Color.parseColor("#32CD32"));
                    p2_a4.setTextColor(Color.parseColor("#32CD32"));
                    p2_a5.setTextColor(Color.parseColor("#32CD32"));
                }
                if (String.valueOf((diferencaPercentual(amostrasP2[3], amostrasP2[4]))) == "NaN")
                    dif4_p2.setText("");
                else
                    dif4_p2.setText(String.valueOf((diferencaPercentual(amostrasP2[3], amostrasP2[4]))));

                mediaPercentualp2 = (diferencaPercentual(amostrasP2[0], amostrasP2[1]) +

                        diferencaPercentual(amostrasP2[1], amostrasP2[2]) +

                        diferencaPercentual(amostrasP2[2], amostrasP2[3]) +

                        diferencaPercentual(amostrasP2[3], amostrasP2[4])) / 4;

                mediaGeralp2 = (amostrasP2[0] + amostrasP2[1] + amostrasP2[2] + amostrasP2[3] + amostrasP2[4]) / 5;

                if (String.valueOf((mediaPercentualp2)) == "NaN") mediaDifP2.setText("");
                else mediaDifP2.setText(String.valueOf((mediaPercentualp2)));

                p2Media.setText(String.valueOf((mediaGeralp2)));
                mediaProduto2.setText(String.valueOf((mediaGeralp2)));
                Double aux = desvioPadrao(amostrasP2);
                desvioProduto2.setText(String.valueOf((aux)));

                if (todosConformeP1 == true && todosConformeP2 == true) {
                    botaoConfirma.setVisibility(View.VISIBLE);
                    pulseAnimation(botaoConfirma);
                }

                if (todosConformeP1 == false || todosConformeP2 == false)
                    botaoConfirma.setVisibility(View.INVISIBLE);

                atualP2++;
            }
        });


        RepositorioMaquinas repositorioMaquinas = new RepositorioMaquinas(getApplication());

        RepositorioUsers repositorioUsers = new RepositorioUsers(getApplication());

        final RepositorioImplementos repositorioImplementos = new RepositorioImplementos(getApplication());


        ArrayList<MAQUINAS> maquinas = new ArrayList<>(repositorioMaquinas.listaMaquinas());

        ArrayList<GGF_USUARIOS> usuarios = new ArrayList<>(repositorioUsers.listaUsuarios());

        ArrayList<IMPLEMENTOS> implementos = new ArrayList<>(repositorioImplementos.listaImplementos());


        ArrayAdapter<MAQUINAS> adapterMaquinas = new ArrayAdapter<MAQUINAS>(this,
                android.R.layout.simple_spinner_item, maquinas);
        adapterMaquinas.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMaquina.setAdapter(adapterMaquinas);


        ArrayAdapter<GGF_USUARIOS> adapterUsuarios = new ArrayAdapter<GGF_USUARIOS>(this,
                android.R.layout.simple_spinner_item, usuarios);
        adapterUsuarios.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerOperador.setAdapter(adapterUsuarios);


        ArrayAdapter<IMPLEMENTOS> adapterImplementos = new ArrayAdapter<IMPLEMENTOS>(this,
                android.R.layout.simple_spinner_item, implementos);
        adapterImplementos.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerImplemento.setAdapter(adapterImplementos);


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_calibragem);

        setSupportActionBar(toolbar);

        getSupportActionBar().

                setSubtitle(/*usuarioLogado.getValue().getEMAIL()*/"a");

        drawer =

                findViewById(R.id.drawer_layout_calibragem);

        NavigationView navigationView = findViewById(R.id.nav_view_calibragem);
        navigationView.setNavigationItemSelectedListener(this);


        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        botaoVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog dialog = new AlertDialog.Builder(ActivityCalibragem.this)
                        .setTitle("Voltar Para o Início?")
                        .setMessage("Caso clique em SIM, você perderá os dados da calibragem!")
                        .setPositiveButton("SIM", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                                Intent it = new Intent(ActivityCalibragem.this, ActivityMain.class);
                                startActivity(it);
                            }
                        }).setNegativeButton("NÃO", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                            }
                        }).create();
                dialog.show();
            }
        });

        botaoConfirma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog dialog = new AlertDialog.Builder(ActivityCalibragem.this)
                        .setTitle("Concluir")
                        .setMessage("Deseja Concluir a Calibragem?")
                        .setPositiveButton("SIM", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                                spinnerImplemento.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                    @Override
                                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                        posicaoImplemento = position;
                                    }

                                    @Override
                                    public void onNothingSelected(AdapterView<?> parent) {
                                    }
                                });

                                spinnerMaquina.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                    @Override
                                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                        posicaoMaquina = position;
                                    }

                                    @Override
                                    public void onNothingSelected(AdapterView<?> parent) {
                                    }
                                });

                                spinnerOperador.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                    @Override
                                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                        posicaoOperador = position;
                                    }

                                    @Override
                                    public void onNothingSelected(AdapterView<?> parent) {
                                    }
                                });

                                RepositorioCALIBRAGEM_SUBSOLAGEM repositorioCALIBRAGEMSubsolagem =
                                        new RepositorioCALIBRAGEM_SUBSOLAGEM(getApplication());

                                RepositorioMAQUINA_IMPLEMENTO repositorioMAQUINA_implemento =
                                        new RepositorioMAQUINA_IMPLEMENTO(getApplication());

                                MAQUINA_IMPLEMENTO maquina_implemento = new MAQUINA_IMPLEMENTO(posicaoMaquina, posicaoImplemento);
                                repositorioMAQUINA_implemento.insert(maquina_implemento);

                                /*repositorioCALIBRAGEMSubsolagem.insert(new CALIBRAGEM_SUBSOLAGEM(osSelecionada.getID_PROGRAMACAO_ATIVIDADE(),
                                        java.sql.Date.valueOf(DateFormat.format("dd-MM-yyyy", new Date()).toString()), checaTurno(), maquina_implemento.getID_MAQUINA_IMPLEMENTO(),
                                        posicaoOperador, mediaGeralp1, desvioPadrao(amostrasP1), mediaGeralp2, desvioPadrao(amostrasP2)));
*/
                                Intent it = new Intent(ActivityCalibragem.this, ActivityContinuarOs.class);
                                startActivity(it);
                            }
                            }).

                            setNegativeButton("NÃO",new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick (DialogInterface dialogInterface,int i){
                                }
                            }).create();
                dialog.show();
            }
        });
    }
                public void pulseAnimation (ImageButton btnObj){
                    objAnim = ObjectAnimator.ofPropertyValuesHolder(btnObj, PropertyValuesHolder.ofFloat("scaleX", 1.5f), PropertyValuesHolder.ofFloat("scaleY", 1.5f));
                    objAnim.setDuration(300);
                    objAnim.setRepeatCount(ObjectAnimator.INFINITE);
                    objAnim.setRepeatMode(ObjectAnimator.REVERSE);
                    objAnim.start();
                }

                @Override
                public boolean onNavigationItemSelected (@NonNull MenuItem item){
                    switch (item.getItemId()) {
                        case R.id.dash:
                            Intent it1 = new Intent(this, ActivityDashboard.class);
                            startActivity(it1);
                            break;

                        case R.id.cadastrar_conta:
                            Intent it2 = new Intent(this, ActivityMain.class);
                            startActivity(it2);
                            break;

                        case R.id.config_login:
                            Intent it3 = new Intent(this, CalculadoraMain.class);
                            startActivity(it3);
                            break;
                    }

                    drawer.closeDrawer(GravityCompat.START);

                    return true;
                }

                private static Double arredondar (Double media){
                    return Math.nextUp(media * 100.f) / 100.f;
                }

                private static Double diferencaPercentual (Double v1, Double v2){
                    Double calculo = ((v2 - v1) / v1) * 100.0;
                    return arredondar(calculo);
                }

                public static Double desvioPadrao (Double[]data){
                    if (data == null) {
                        throw new IllegalArgumentException("Null 'data' array.");
                    }
                    if (data.length == 0) {
                        throw new IllegalArgumentException("Zero length 'data' array.");
                    }
                    Double avg = calculateMean(data, false);
                    Double sum = 0.0;

                    for (int counter = 0; counter < data.length; counter++) {
                        Double diff = Double.valueOf(data[counter]) - avg;
                        sum = sum + diff * diff;
                    }
                    return Math.sqrt(sum / (data.length - 1));
                }

                public static Double calculateMean (Double[]values,
                boolean includeNullAndNaN){

                    if (values == null) {
                        throw new IllegalArgumentException("Null 'values' argument.");
                    }
                    Double sum = 0.0;
                    Double current;
                    int counter = 0;
                    for (int i = 0; i < values.length; i++) {
                        if (values[i] != null) {
                            Double.valueOf(current = values[i]);
                        } else {
                            current = Double.NaN;
                        }
                        if (includeNullAndNaN || !Double.isNaN(current)) {
                            sum = sum + current;
                            counter++;
                        }
                    }
                    Double result = (sum / counter);
                    return result;
                }

                public String abreDialogo () {
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Digite O Valor da Amostra!");

                    final EditText input = new EditText(this);
                    input.setInputType(InputType.TYPE_CLASS_PHONE);
                    builder.setView(input);
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            texto = input.getText().toString();
                        }
                    });

                    builder.show();
                    return texto;
                }

    /*public Double truncarDecimais(Double x, int numeroDecimais)
    {
        if ( x > 0) {
            BigDecimal bd1 = new BigDecimal(String.valueOf(x)).setScale(numeroDecimais, BigDecimal.ROUND_FLOOR);
            return Double.valueOf(String.valueOf(bd1));
        } else {
            BigDecimal bd2 = new BigDecimal(String.valueOf(x)).setScale(numeroDecimais, BigDecimal.ROUND_CEILING);
            return Double.valueOf(String.valueOf(bd2));
        }
    }*/

                public int verificaDecimais (Double s){
                    int dec = String.valueOf(s).split("\\.")[1].length();
                    Toast.makeText(this, String.valueOf(dec), Toast.LENGTH_LONG).show();
                    return dec;
                }

    private String checaTurno() {

        String pattern = "HH:mm";
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        String horaAtual = DateFormat.format("HH:mm", new Date()).toString();
        String meioDia = "12:00";
        try {
            Date date1 = sdf.parse(horaAtual);
            Date date2 = sdf.parse(meioDia);

            if(date1.before(date2)) {
                return "Manha";
            } else {
                return "Tarde";
            }
        } catch (ParseException e){
            e.printStackTrace();
        }
        return "Erro";
                }

                @Override
                public void onBackPressed () {
                    if (drawer.isDrawerOpen(GravityCompat.START)) {
                        drawer.closeDrawer(GravityCompat.START);
                    }
                }
            }
