package com.example.forestsys;

import android.text.format.DateFormat;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DataHoraAtual {

    //Retorna a data atual do dispositivo
    public static Date dataHora(){
        Date pegaDataHora = (Date) DateFormat.format("dd-MM-yyyy 'Ás' hh:mm", new Date());
        return (pegaDataHora);
    }

    public static Date somenteData(){
        SimpleDateFormat formatoHora = new SimpleDateFormat("dd-MM-yyyy");
        String s = formatoHora.format( new java.util.Date());

        Date data = null;
        try {
            data = formatoHora.parse (s);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return (data);
    }}